package com.customer.service;

import java.util.List;

import com.customer.bean.Customer;
import com.customer.exception.CustomerException;

public interface CustomerService {

	public List<Customer> addCustomer(Customer cust) throws CustomerException;
	public Customer getCustomerById(int Id) throws CustomerException;
	public void deleteCustomer (int id) throws CustomerException;
	public List<Customer> getAllCustomer() throws CustomerException;
	public List<Customer> getCustomerByCity(String city) throws CustomerException;
	public List<Customer> updateCustomer(int id, Customer cust) throws CustomerException;
	
	
}
